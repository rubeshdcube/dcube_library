from setuptools import setup

setup(name='dcube',
	  version='0.1',
	  description='Library for Symphony Data Model',
	  author='Dcube Analytics Pvt Ltd',
	  author_email='dds@d3analytics.com',
	  Packages=['dcube', 'dcube.symphony'],
	  )

__author__ = 'Dcube Analytics Pvt Ltd'

